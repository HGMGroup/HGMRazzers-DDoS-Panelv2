﻿<?php
$ip = $_SERVER['REMOTE_ADDR'];
?>
<style>
body {
	font-family: calibri,tahoma,verdana,terminal,serif,lucida,system;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	color: #7CFC00;
	background-color: #000000;
}

.HGMRazzers_Buton {
width: 240px;
border: solid 2px #00BCFF;
background-color: #000000;
padding: 3px;
cursor: pointer }

input:hover , input:active { border-color: #FF0000 }

</style>
<center><br><br>
<img src="HGMRbackground.PNG"><br>

<form id="form1" name="form1" method="post"action="HGMRazzers-DD0S-Panel.php"><table width="348" border="0" align="center">

<?php
echo "<b><font size=3>|-------------------------------------------------------------------------|</font></b>";
echo "<b><font size=3><br>HGMRazzers-</font><font color=red><font size=3>DDoS</font><font color=#7CFC00><font size=3>-Panel;</font></b><br>";
echo "<b><font size=3>|-------------------------------------------------------------------------|</font></b>";
echo "<b><font size=2><br>Burasi; <font color=red>Coluk Cocuklar gibi </font></b><br>";
echo "<b><font size=2>Hareketlere <font color=red>Uygun Degildir.</font></b><br>";
echo "<b><font size=2>Kullandiginiz Ip Adresi:<font color=red> $ip </font></b><br>";
echo "<b><font size=2><font color=red>Kayıt Edilmektedir</font><font color=#7CFC00> [ Tabikide Sakaydi ] <font color=red>;)</font></b><br>";
echo "<b><font size=2>Sisteme Sifresiz<font color=red> ERISEMEZSINIZ..!</font></b><br>";
echo "<b><font size=2>Not: Fazla Saldiri Cikisindan<font color=red> Sunucunuz Kapanabilir.</font></b><br>";
echo "<b><font size=3>|-------------------------------------------------------------------------|</font></b>";
?>
<br>
<input type="text" class="HGMRazzers_Buton" style=color:red name="Sifre" id="Sifre" value = "Sifre" onblur = "if ( this.value=='' ) this.value = 'Sifre';" onfocus = " if ( this.value == 'Sifre' ) this.value = '';"/><br>
<?php
echo "<b><font size=3>|-------------------------------------------------------------------------|</font></b>";
?>
<br>
<label>
</label>

</table>
</form>

<input type="submit" value="Giris -->" class="HGMRazzers_Buton" style="color:red" name="button" id="button" value="GIRIS" /> <br><br>
<input type="button" value="<-- Geri Donme" class="HGMRazzers_Buton" style="color:#7CFC00" onclick="window.location.href='/HGMRazzers/HGMRazzers-DDoS-Panel.php'" /> </td>