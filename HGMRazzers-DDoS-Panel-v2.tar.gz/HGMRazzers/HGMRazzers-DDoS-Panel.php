<?php
$ip = $_SERVER['REMOTE_ADDR'];
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
	<meta name="author" content="HGMRazzers By HGM">

	<title>HGMRazzers DDoS Panel</title>
</head>
<!-- PHP DOS, coded by HGMRazzers By HGM -->
<style type="text/css">
<!--

body {
	font-family: calibri,tahoma,verdana,terminal,serif,lucida,system;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	color: #FFFFFF;
	background-color: #000000;
}

.HGMR_Text_Kutusu_1 {
width: 145px;
border: solid 2px #00BCFF;
background-color: #000000;
padding: 3px;
cursor: pointer }

.HGMRazzers_Buton {
width: 240px;
border: solid 2px #00BCFF;
background-color: #000000;
padding: 3px;
cursor: pointer }


input:hover , input:active { border-color: #FF0000 }


-->
</style>
<!-- PHP DOS, coded by HGMRazzers By HGM -->
<body>
<center><br><br>
<img src="HGMRbackground.PNG"><br>
<b>Kullandiginiz Ip:</b> <font color="red"> <font size=2> <b><?php echo $ip; ?></b></font><font color=#FFFFFF><font size=2> &nbsp;<b>(Salak Gibi Kendinize<font color =red> Vurmayin..!</font>)</font><br><br>
<form name="input" action="HGMR_dd0s.php" method="post">
Hedef IP:
<input type="text" name="ip" size="15" maxlength="15" style="color:red" class="HGMR_Text_Kutusu_1" value = "0.0.0.0" onblur = "if ( this.value=='' ) this.value = '0.0.0.0';" onfocus = " if ( this.value == '0.0.0.0' ) this.value = '';">
&nbsp;Saldiri Suresi:
<input type="text" name="time" size="14" maxlength="20" style="color:#7CFC00" class="HGMR_Text_Kutusu_1" value = "Sure: (Saniye Olarak)" onblur = "if ( this.value=='' ) this.value = 'Sure: (Saniye Olarak)';" onfocus = " if ( this.value == 'Sure: (Saniye Olarak)' ) this.value = '';">
&nbsp;Hedef Port:
<input type="text" name="port" size="5" maxlength="5" style="color:#7CFC00" class="HGMR_Text_Kutusu_1" value = "port" onblur = "if ( this.value=='' ) this.value = 'port';" onfocus = " if ( this.value == 'port' ) this.value = '';">
<br><br>
<td>
<input type="submit" value="Saldiriyi Baslat -->" class="HGMRazzers_Buton" style="color:red"> &nbsp; <input type="button" value="Iplogger Sistemi." class="HGMRazzers_Buton" style="color:#7CFC00" onclick="window.location.href='/HGMNetwork_IpLogger_Script_Logs.txt'" /> </td>
<br><br>
<center>
<b><font color="red"> <font size=3> <?php echo "**Saldiriyi Atarken Siteden CIKMAYIN..!**"; ?></font></b>
</center>

</form>
</center>
<!-- PHP DOS, coded by HGMRazzers By HGM -->
</body>
</html>